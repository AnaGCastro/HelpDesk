package br.com.nava.services;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.domain.Chamado;
import br.com.nava.domain.Cliente;
import br.com.nava.domain.Tecnico;
import br.com.nava.domain.enums.Perfil;
import br.com.nava.domain.enums.Prioridade;
import br.com.nava.domain.enums.Status;
import br.com.nava.repositories.ChamadoRepository;
import br.com.nava.repositories.ClienteRepository;
import br.com.nava.repositories.TecnicoRepository;

@Service
public class DBService {

	@Autowired
	private TecnicoRepository tecnicoRepository;

	private ClienteRepository clienteRepository;

	private ChamadoRepository chamadoRepository;

	public void instanciaDB() {
		Tecnico tec1 = new Tecnico(null, "Hope Mikaelson", "35587447219", "hopeM@gmail.com", "123");
		tec1.addPerfil(Perfil.ADMIN);

		Cliente cli1 = new Cliente(null, "Bonnie Bennet", "58279583360", "bonnieB@gmail.com", "123");

		Chamado ch1 = new Chamado(null, Prioridade.MEDIA, Status.ANDAMENTO, "Chamado 01", "Primeiro chamado", tec1,
				cli1);

		tecnicoRepository.saveAll(Arrays.asList(tec1));
		clienteRepository.saveAll(Arrays.asList(cli1));
		chamadoRepository.saveAll(Arrays.asList(ch1));

	}

}
