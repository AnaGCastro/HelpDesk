package br.com.nava.domain.enums;

public enum Status {
	
// ESTA CLASSE INDICA QUE OS VALORES DENTRO DELA SERÃO FIXOS, OU SEJA, SERÃO UTILIZADAS SEMPRE DESTA FORMA
	
	
	ABERTO(0, "ABERTO"), ANDAMENTO(1, "ANDAMENTO"), ENCERRADO(2, "ENCERRADO");
	
	private Integer codigo;
	private String descrcao;
	
	private Status(Integer codigo, String descrcao) {
		this.codigo = codigo;
		this.descrcao = descrcao;
	}

	public Integer getCodigo() {
		return codigo;
	}


	public String getDescrcao() {
		return descrcao;
	}

	
	public static Status toEnum(Integer cod) {
		if (cod == null) {
			return null;
		}
		
		for (Status x : Status.values()) {
			if(cod.equals(x.getCodigo())) {
				return x;
			}
		}
		
		throw new IllegalArgumentException("Status inválido");
	}

	
	

}
