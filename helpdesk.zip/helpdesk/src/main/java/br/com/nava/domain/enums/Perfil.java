package br.com.nava.domain.enums;

public enum Perfil {
	
// ESTA CLASSE INDICA QUE OS VALORES DENTRO DELA SERÃO FIXOS, OU SEJA, SERÃO UTILIZADAS SEMPRE DESTA FORMA
	
	
	ADMIN(0, "ROLE_ADMIN"), CLIENTE(1, "ROLE_CLIENTE"), TECNICO(2, "ROLE_TECNICO");
	
	private Integer codigo;
	private String descrcao;
	
	private Perfil(Integer codigo, String descrcao) {
		this.codigo = codigo;
		this.descrcao = descrcao;
	}

	public Integer getCodigo() {
		return codigo;
	}


	public String getDescrcao() {
		return descrcao;
	}

	
	public static Perfil toEnum(Integer cod) {
		if (cod == null) {
			return null;
		}
		
		for (Perfil x : Perfil.values()) {
			if(cod.equals(x.getCodigo())) {
				return x;
			}
		}
		
		throw new IllegalArgumentException("Perfil inválido");
	}

	
	

}
