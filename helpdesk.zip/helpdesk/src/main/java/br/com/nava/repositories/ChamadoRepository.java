package br.com.nava.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.nava.domain.Chamado;



public interface ChamadoRepository extends JpaRepository<Chamado, Integer>{
	
	

}
