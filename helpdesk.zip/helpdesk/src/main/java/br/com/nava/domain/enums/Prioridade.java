package br.com.nava.domain.enums;

public enum Prioridade {
	
// ESTA CLASSE INDICA QUE OS VALORES DENTRO DELA SERÃO FIXOS, OU SEJA, SERÃO UTILIZADAS SEMPRE DESTA FORMA
	
	
	BAIXA(0, "BAIXA"), MEDIA(1, "MEDIA"), ALTA(2, "ALTA");
	
	private Integer codigo;
	private String descrcao;
	
	private Prioridade(Integer codigo, String descrcao) {
		this.codigo = codigo;
		this.descrcao = descrcao;
	}

	public Integer getCodigo() {
		return codigo;
	}


	public String getDescrcao() {
		return descrcao;
	}

	
	public static Prioridade toEnum(Integer cod) {
		if (cod == null) {
			return null;
		}
		
		for (Prioridade x : Prioridade.values()) {
			if(cod.equals(x.getCodigo())) {
				return x;
			}
		}
		
		throw new IllegalArgumentException("Prioridade inválido");
	}

	
	

}
