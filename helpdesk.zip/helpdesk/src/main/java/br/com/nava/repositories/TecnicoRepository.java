package br.com.nava.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.nava.domain.Tecnico;


public interface TecnicoRepository extends JpaRepository<Tecnico, Integer>{
	
	

}
